
function updateCarInfo() {
    var currentCar = cars[currentIndex];
    var carInfoDiv = document.getElementById('garage-content');
    carInfoDiv.innerHTML = '<h2>Current Car</h2>' + '<p>' + currentCar.name + '</p>' + '<p>' + currentCar.name + '</p>' + '<p>' + currentCar.name + '</p>';
}

function showPreviousCar() {
    currentIndex = (currentIndex - 1 + cars.length) % cars.length;
    updateCarInfo();
}

function showNextCar() {
    currentIndex = (currentIndex + 1) % cars.length;
    updateCarInfo();
}

updateCarInfo();
