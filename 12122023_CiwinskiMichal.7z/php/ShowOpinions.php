
<?php
// Pobierz wszystkie opinie z bazy danych i wyświetl
$servername = "localhost";
$username = "user";
$password = "password";
$dbname = "websitephp";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//SELECT comments.firstname, comments.lastname, gender.gendername FROM `comments` LEFT JOIN `gender` ON comments.gender_id_fk = gender.ID
$result_all = $conn->query("SELECT comments.ID, comments.firstname, comments.lastname, comments.comment, comments.date, comments.ParentID FROM `comments`");
echo $result_all;


$result_parents = $conn->query("SELECT comments.ID, comments.firstname, comments.lastname, comments.comment, comments.date, comments.ParentID FROM `comments` WHERE comments.ParentID IS NULL ");


$result_childrens = $conn->query("SELECT comments.ID, comments.firstname, comments.lastname, comments.comment, comments.date, comments.ParentID FROM `comments` WHERE (comments.ParentID IS NOT NULL AND comments.Level=1)");



if ($result_parents->num_rows > 0) {
    echo "<div class='comments-div'>";

    while ($row = $result_parents->fetch_assoc()) {
        echo "
        <div class='comment-div'>
            <div class='bold-art'> " . $row['firstname'] . " " . $row['lastname']  .  " " . $row['date'] ." </div>
            <div class='comment-row'> ". $row['comment'] ." </div>
        </div>";
    }

    echo "</div>";
} else {
    echo "Brak opinii.";
}

$conn->close();
?>