<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Title</title>
  <link rel="stylesheet" href="../css/main.css">
</head>
<body>
  <div class="nawigacja">
    <ul>
      <li><a href="../main.html">Strona glowna</a></li>
      <li><a href="contact.php">Kontakt</a></li>
      <li><a href="onas.html">O nas</a></li>
      <li><a href="uslugi.html">Uslugi</a></li>
      <li><a href="opinions.php">Opinie</a></li>
    </ul>
  </div>

  <div id="list-of-opinions">
      <?php include '../php/ShowOpinions.php'; ?>
  </div>


  <div class="opinie-container">

          <form class ="form-opinie" action="../php/PostOpinion.php" method="post">
              <label for="imie">Imię:</label>
              <input class ="form-input" type="text" id="imie" name="imie" required>

              <label for="nazwisko">Nazwisko:</label>
              <input class ="form-input" type="text" id="nazwisko" name="nazwisko" required>
              <div id="radio-div">
                  <div class="radio-element">
                      <input type="radio" id="men" name="gender-radio" value="Men">
                      <label for="Men">Men</label><br>
                  </div>
                  <div class="radio-element">
                  <input type="radio" id="women" name="gender-radio" value="Women">
                  <label for="Women">Women</label><br>
                  </div>
                  <div class="radio-element">
                      <input type="radio" id="other" name="gender-radio" value="Other">
                      <label for="Other">Other</label>
                  </div>
              </div>

              <label for="komentarz">Komentarz:</label>
              <textarea class ="form-textarea" id="komentarz" name="komentarz" required></textarea>

              <input class ="form-button-submit" type="submit" value="Wyślij">
          </form>
  </div>

</body>
</html>
