<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="../css/htmlphp.css">
</head>
<body>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $imie = $_POST['imie'];
    $nazwisko = $_POST['nazwisko'];
    $komentarz = $_POST['komentarz'];

    echo "Dziękujemy za Twoją opinię $imie $nazwisko" ;
    echo "<br>";
    echo "<textarea>$komentarz</textarea>";
    //<textarea> asdas</textarea>
    //<?php
    echo "<script>
            setTimeout(function() {
                window.location.href = '../podstrony/opinie.html'; 
            }, 3000);  
          </script>";
} else {
    echo "Napotkalismy problem, powtórz swoją opinie";
    echo "<script>
            setTimeout(function() {
                window.location.href = '../podstrony/opinie.html'; 
            }, 3000);  
          </script>";
}
?>

</body>
</html>