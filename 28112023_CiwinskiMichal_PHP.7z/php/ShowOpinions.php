
<?php
// Pobierz wszystkie opinie z bazy danych i wyświetl
$servername = "localhost";
$username = "user";
$password = "password";
$dbname = "websitephp";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//SELECT comments.firstname, comments.lastname, gender.gendername FROM `comments` LEFT JOIN `gender` ON comments.gender_id_fk = gender.ID
$result = $conn->query("SELECT comments.firstname, comments.lastname, comments.comment FROM `comments`");

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<p>" . $row['firstname'] . " " . $row['lastname'] . ": " . $row['comment'] . "</p>";
    }
} else {
    echo "Brak opinii.";
}

$conn->close();
?>