<?php
include '../php/dbCarsService.php';
//DB service
$conn = connectToDatabase();
$cars = fetchCarsFromDatabase($conn);
closeDatabaseConnection($conn);

$carsJson = json_encode($cars);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ciwi Automotive - Garage</title>
    <link rel="stylesheet" href="../css/style.css">
    <script>
        var cars = <?php echo $carsJson; ?>;
        var currentIndex = 0;

        var carManagerScript = document.createElement('script');
        carManagerScript.src = '../js/CarManager.js';
        document.head.appendChild(carManagerScript);
    </script>
</head>
<body>

    <div class="background">
        <div class="navigation">
            <div class="nav-logo">

            </div>
            <div class="nav-options">
                <div class="nav-option" id="home"><a class="nav-a-style" href="../mainSite.html">Home</a></div>
                <div class="nav-option" id="garage"><a class="nav-a-style" style="color: #3BB0D1;"  href="garage.php" >Garage</a></div>
                <div class="nav-option" id="contact"><a class="nav-a-style" href="contact.html">Contact</a></div>
                <div class="nav-option" id="opinions"><a class="nav-a-style" href="opinions.php">Opinions</a></div>
            </div>
        </div>

        <div id="garage-content">
            <!-- dynamic JS content -->
        </div>



        <button onclick="showPreviousCar()">Previous Car</button>
        <button onclick="showNextCar()">Next Car</button>

    </div>



</body>
</html>
