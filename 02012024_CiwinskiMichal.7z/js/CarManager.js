
function updateCarInfo() {
    var currentCar = cars[currentIndex];
    var carInfoDiv = document.getElementById('garage-content');
    carInfoDiv.innerHTML = '<h2>Current Car</h2>' + '<p>' + currentCar.name + '</p>' + '<p>' + currentCar.name + '</p>' + '<p>' + currentCar.name + '</p>';
}

function showPreviousCar() {
    currentIndex = (currentIndex - 1 + cars.length) % cars.length;
    updateCarInfo();
}

function showNextCar() {
    currentIndex = (currentIndex + 1) % cars.length;
    updateCarInfo();
}

updateCarInfo();


function myFunction(pictNumber){
    switch (pictNumber) {
        case 'but-1':
            console.log('1');
            document.getElementById("picture").src="img/pierwsze.jpg";
            break;
        case 'but-2':
            console.log('2');
            document.getElementById("picture").src="img/firstcar.png" ;
            break;
        case 'but-3':
            console.log('3');
            document.getElementById("picture").src="img/trzecie.jpg" ;
            break;
        case 'but-4':
            console.log('4');
            document.getElementById("picture").src="img/czwarte.jpg" ;
            break;
        default:
            console.log('1');
            document.getElementById("picture").src="img/pierwsze.jpg";
            break;
    }
}